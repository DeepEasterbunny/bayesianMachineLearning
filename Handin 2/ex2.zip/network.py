import jax.numpy as jnp
from jax import random
import matplotlib.pyplot as plt
import seaborn as snb

from mpl_toolkits.axes_grid1 import make_axes_locatable

from scipy.optimize import minimize
from jax import value_and_grad
from jax import grad
from jax.scipy.stats import norm
from jax import hessian
# from jax.misc.optimizers import adam
from jax.flatten_util import ravel_pytree

def log_npdf(x, m, v):
    return -0.5*(x-m)**2/v - 0.5*jnp.log(2*jnp.pi*v)




#######################################################################################
# Neural network model with MAP inference
# Adapted from: # https://github.com/HIPS/autograd/blob/master/examples/neural_net.py
########################################################################################

class SimpleNeuralNet(object):

    def __init__(self, X, y, tau, activation_fun , likelihood, alpha=1., step_size=0.01, max_itt=1000, seed=0, layer_sizes = None, ):

        # data
        self.X = X
        self.y = y

        # model and optimization parameters
        self.likelihood = likelihood#(y)
        self.layer_sizes = layer_sizes
        self.step_size = step_size
        self.max_itt = max_itt
        self.alpha = alpha
        self.activation_fun = activation_fun
        self.tau = tau

        # random number genration
        self.seed = seed
        self.key = random.PRNGKey(self.seed)
        
        # initialize parameters and optimize
        self.params = self.init_random_params()
        self.optimize_adam()


    def init_random_params(self):
        """Build a list of (weights, biases) tuples,
        one for each layer in the net."""
        parameters = self.tau * random.normal(shape = (2,), key = self.key)
        # parameters = []
        # for m, n in zip(self.layer_sizes[:-1], self.layer_sizes[1:]):
        #     self.key, subkey = random.split(self.key)
        #     w_key, b_key = random.split(subkey, 2)
        #     weight_matrix =jnp.sqrt(2/n) * random.normal(w_key, shape=(m, n))
        #     bias_vector = jnp.sqrt(2/n) * random.normal(b_key, shape=(n))
        #     parameters.append((weight_matrix, bias_vector))

        return parameters

    def forward_pass(self, params, inputs):
        """Implements a deep neural network for classification.
        params is a list of (weights, bias) tuples.
        inputs is an (N x D) matrix.
        returns logits."""

        outputs = self.activation_fun(inputs + params[0]) * params[1]

        # for W, b in params:
        #     outputs = jnp.dot(inputs, W) + b
        #     inputs = jnp.tanh(outputs)
        return outputs# - logsumexp(outputs, axis=1, keepdims=True)
    
    def sample_from_prior_weights(self, n):
        return self.tau * random.normal(shape = (n, 2), key = self.key)
    
    def sample_fs(self, ws , xmin, xmax, m):
        n = len(ws)
        # fs = jnp.zeros(shape = (n, m), dtype=jnp.float32)
        xs = jnp.linspace(xmin, xmax, num = m)
        xs = xs[None,:]
        xs = jnp.repeat(xs, n, axis = 0)
        # print(xs.shape)
        # ws = self.sample_from_prior_weights(n)
        # print(ws.shape)
        w0s = ws[:, 0]
        w1s = ws[:, 1]
        # print(w1s.shape)
        # print(w1s[:, None].shape)
        
        return w1s[:, None] * self.activation_fun(xs + w0s[:, None])


    def forward(self, inputs):
        return self.forward_pass(self.params, inputs)

    def log_prior(self, params):
        # implement a Gaussian prior on the weights
        flattened_params, _ = ravel_pytree(params)
        return  jnp.sum(log_npdf(params, 0., 1/self.alpha))
    
    def log_likelihood(self, params):     
        y = self.forward_pass(params, self.X)
        f = self.params[1] * self.activation_fun(self.X + self.params[0])
        return self.likelihood.log_lik(y, f)

    def log_posterior(self, params):
        return self.log_prior(params) + self.log_likelihood(params)

    def optimize_adam(self, b1=0.9, b2=0.999, eps=1e-8):
    
        # Define training objective and gradient of objective using autograd.
        def objective(params, iter):
            return -self.log_posterior(params)
            
        objective_grad = grad(objective)
        params_flat, unflatten = ravel_pytree(self.params)
        params = self.params

        m = jnp.zeros(len(params_flat))
        v = jnp.zeros(len(params_flat))

        for itt in range(self.max_itt):

            # compute gradient and flatten
            g = objective_grad(params, itt)
            g, _ = ravel_pytree(g)

            # ADAM update rules
            m = (1 - b1) * g + b1 * m  # First  moment estimate.
            v = (1 - b2) * (g**2) + b2 * v  # Second moment estimate.
            mhat = m / (1 - b1 ** (itt + 1))  # Bias correction.
            vhat = v / (1 - b2 ** (itt + 1))
            params_flat = params_flat - self.step_size * mhat / (jnp.sqrt(vhat) + eps)
            params = unflatten(params_flat)

        self.params = params

        return self

#######################################################################################
# Helper function for sampling multivariate Gaussians
########################################################################################


def generate_samples(key, mean, K, M, jitter=1e-8):
    """ returns M samples from a zero-mean Gaussian process with kernel matrix K
    
    arguments:
    K      -- NxN kernel matrix
    M      -- number of samples (scalar)
    jitter -- scalar
    returns NxM matrix
    """
    
    L = jnp.linalg.cholesky(K + jitter*jnp.identity(len(K)))
    zs = random.normal(key, shape=(len(K), M))
    fs = mean + jnp.dot(L, zs)
    return fs

#######################################################################################
# For plotting
########################################################################################

def plot_with_uncertainty(ax, Xp, mu, Sigma, sigma=0, color='g', color_samples='g', title="", num_samples=0, seed=0):
    
    mean, std = mu.ravel(), jnp.sqrt(jnp.diag(Sigma) + sigma**2)

    
    # plot distribution
    ax.plot(Xp, mean, color=color, label='GP')
    ax.plot(Xp, mean + 2*std, color=color, linestyle='--')
    ax.plot(Xp, mean - 2*std, color=color, linestyle='--')
    ax.fill_between(Xp.ravel(), mean - 2*std, mean + 2*std, color=color, alpha=0.25, label='95% interval')
    
    # generate samples
    if num_samples > 0:
        key = random.PRNGKey(seed)
        fs = generate_samples(key, mu[:, None], Sigma, num_samples, 1e-6)
        ax.plot(Xp, fs, color=color_samples, alpha=.25)
    
    ax.set_title(title)

    if num_samples > 0:
        return fs
    

def add_colorbar(im, fig, ax):
    divider = make_axes_locatable(ax)
    cax = divider.append_axes('right', size='5%', pad=0.05)
    fig.colorbar(im, cax=cax, orientation='vertical')
        
def eval_density_grid(density_fun, P=100, a=-5, b=5):
    x_grid = jnp.linspace(a, b, P)
    X1, X2 = jnp.meshgrid(x_grid, x_grid)
    XX = jnp.column_stack((X1.ravel(), X2.ravel()))
    return x_grid, density_fun(XX).reshape((P, P))


#######################################################################################
# compute classification error and std. error of the mean
########################################################################################


def compute_err(t, tpred):
    return jnp.mean(tpred.ravel() != t), jnp.std(tpred.ravel() != t)/jnp.sqrt(len(t))

